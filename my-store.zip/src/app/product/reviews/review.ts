export class Review{
    name!:string;
    email!:string;
    rating!:number;
    description!:string;
}